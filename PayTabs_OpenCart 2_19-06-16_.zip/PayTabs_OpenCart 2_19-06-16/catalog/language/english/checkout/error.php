<?php
// Heading
$_['heading_title'] = 'Oops..!';

// Text
$_['text_customer'] = '<p> The Payment is rejected.<p>';
$_['text_checkout'] = 'Checkout';
?>